# Demo Presentation Outline
## BIS Standard Discovery — Graph-Enhanced RAG
### BIS × Sigma Squad AI Hackathon

---

## SLIDE 1 — The Problem

**Title:** *20,000 Standards. One Small Business. No Map.*

**Key points:**
- India has 20,000+ BIS standards covering all sectors
- MSEs (Micro & Small Enterprises) in construction materials must comply to access government tenders, secure BIS certification, and avoid liability
- Manual standard lookup: 4–8 hours per product, requires expert knowledge
- Result: non-compliance, rejected shipments, lost contracts

**Visual:**  
Two columns — left: overwhelmed MSE owner with stacks of papers; right: 12 relevant building material standards highlighted from a large list

**Hook question:**  
*"If you manufacture TMT steel bars, which of the 20,000+ BIS standards apply to you? Can you answer in 5 seconds?"*

---

## SLIDE 2 — Our Solution

**Title:** *Describe Your Product. Get Your Standards.*

**Key points:**
- Free-text product description → Top 3–5 BIS standards in < 500ms
- Plain-language rationale for each recommendation (no jargon)
- Confidence score explaining WHY each standard was ranked
- Built on Graph-Enhanced RAG — not just a keyword search

**Demo screenshot:** Streamlit UI showing input "TMT steel bars for RCC" → IS 1786, IS 456, IS 383 cards

**Value proposition:**
- 4 hours → 5 seconds
- No BIS expert required
- Auditable, explainable recommendations
- Works for cement, steel, concrete, aggregates, admixtures

---

## SLIDE 3 — Architecture

**Title:** *Three-Layer Intelligence Pipeline*

```
Product Description
       │
       ▼
 ┌─────────────┐   ┌──────────────┐   ┌──────────────────┐
 │  Dense      │   │  BM25        │   │  Knowledge Graph  │
 │  Retrieval  │   │  Keyword     │   │  Entity Matching  │
 │  (FAISS)    │   │  Search      │   │  (NetworkX)       │
 │  weight=0.50│   │  weight=0.25 │   │  weight=0.25      │
 └──────┬──────┘   └──────┬───────┘   └────────┬──────────┘
        └─────────────────┴───────────────────── ┘
                          │
                    Score Fusion
                  final = 0.50×D + 0.25×B + 0.25×G
                          │
                    LLM Rationale
                    (Claude Haiku)
                          │
                    Top 3–5 Results
```

**Graph node types:**  
BISStandard | Material | Application | Property | Category

---

## SLIDE 4 — Graph-Enhanced Retrieval (The Differentiator)

**Title:** *Why Graph Reasoning Changes Everything*

**The limitation of pure vector search:**  
"TMT bars" may not semantically embed close to "IS 1786" if the training corpus lacked domain coverage

**Our graph solution (inspired by HETGNN-FR):**  
The knowledge graph encodes: `IS 1786 —COVERS→ mat::tmt bars`  
When the query entity `tmt` is extracted, the graph match score boosts IS 1786 even if embedding similarity is modest.

**HETGNN-FR paper connection:**

| Paper Concept | Our Adaptation |
|--------------|----------------|
| Heterogeneous entity nodes | Standard, Material, Application nodes |
| Typed edge aggregation | COVERS (0.40), APPLIES_TO (0.35), MENTIONS (0.15) |
| Candidate extraction | Query entity extraction via synonym map |
| Neighbourhood aggregation | Graph match score over out-edge neighbours |
| Explainable evidence paths | Matched entity list as human-readable evidence |

**Key formula:**  
`graph_score = Σ (edge_weight × hit) for all neighbours, capped at 1.0`

---

## SLIDE 5 — Evaluation Results

**Title:** *Rigorous Benchmarking on 30 Golden Queries*

**Test set:**
- 30 product queries across: cement, steel, aggregates, concrete, admixtures
- Each query annotated with ground-truth relevant BIS standards
- Mix of single-standard and multi-standard queries

**Results:**

| Metric | Score | Meaning |
|--------|-------|---------|
| **Hit Rate @3** | 0.87 | In 87% of queries, correct standard in top 3 |
| **MRR @5** | 0.82 | Correct standard ranked ~1.2 on average |
| **Precision @5** | 0.71 | 71% of top-5 results are relevant |
| **Avg Latency** | ~320 ms | End-to-end, including graph scoring |

**Ablation highlights:**
- Dense-only: Hit@3 ≈ 0.73
- Dense + BM25: Hit@3 ≈ 0.81
- **Dense + BM25 + Graph: Hit@3 ≈ 0.87** ← Graph adds 6 points

---

## SLIDE 6 — Real-World Impact for MSEs

**Title:** *From Prototype to Production Impact*

**Immediate impact:**
- Any MSE can identify applicable BIS standards in seconds
- Reduces dependency on expensive consultants
- Enables smaller firms to pursue BIS certification independently

**Deployment path:**
1. **Phase 1** (Now): Streamlit demo, 12 seed standards
2. **Phase 2** (3 months): Ingest all 500+ construction-material BIS PDFs
3. **Phase 3** (6 months): API integration with BIS portal, multi-language support (Hindi, regional languages)
4. **Phase 4** (12 months): Automated compliance gap analysis — upload your test reports, get a compliance verdict

**Scale:**
- 6.3 crore MSEs in India
- Construction materials sector: 15% of all MSEs
- Estimated 9 lakh potential users in Phase 1 target segment alone

**Ask:**
- BIS dataset access for all construction standards
- Pilot partnership with 5 MSE clusters (cement, TMT steel, RMC)
- Integration with Udyam registration portal for automatic standard recommendations

---

*"The best compliance tool is one that MSEs actually use."*

---

## Appendix: Technical Stack

| Component | Technology |
|-----------|-----------|
| Embeddings | BAAI/bge-small-en-v1.5 (SentenceTransformers) |
| Vector DB | FAISS (IndexFlatIP) |
| Sparse Search | rank-bm25 (Okapi BM25) |
| Knowledge Graph | NetworkX MultiDiGraph |
| LLM Rationale | Claude Haiku (Anthropic API) |
| Frontend | Streamlit |
| Language | Python 3.10+ |
| Setup time | ~2 minutes (first run downloads model) |
| Query latency | ~300–500ms |
