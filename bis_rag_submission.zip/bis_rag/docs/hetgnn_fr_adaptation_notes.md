# HETGNN-FR → BIS Discovery: Technical Adaptation Notes

## How HETGNN-FR Inspired This System

### Original Paper: HETGNN-FR
**"HETGNN-FR: Detecting Coordinated Fraud Rings in Dynamic Financial Networks"**

The paper addresses a graph-based ML problem: given a heterogeneous temporal
financial network (accounts, transactions, devices, merchants), detect coordinated
fraud rings by aggregating multi-hop entity relationships.

### Key Paper Concepts Adapted

---

#### 1. Heterogeneous Graph Construction

**In HETGNN-FR:**  
Nodes are typed entities: `Account | Merchant | Device | IP`.  
Edges encode relationships: `TRANSACTS_WITH | USES | SHARES`.

**In Our System:**  
Nodes are typed entities: `BISStandard | Material | Application | Property | Category`.  
Edges encode: `COVERS | APPLIES_TO | MENTIONS | BELONGS_TO`.

The key insight is the same: **typed heterogeneity enables richer reasoning than
a homogeneous graph** because different relation types carry different semantics and
should be weighted accordingly.

---

#### 2. Candidate Extraction

**In HETGNN-FR:**  
A seed set of suspicious accounts is first identified before neighbourhood
aggregation — this is the "candidate extraction" phase.

**In Our System:**  
We extract query entities (materials, applications, properties) from the input text
as the "seed" before graph traversal. The function `extract_query_entities()` mirrors
this exactly — it identifies which entity types appear in the query before the
graph scoring begins.

---

#### 3. Relation-Type Weighted Aggregation

**In HETGNN-FR:**  
Different edge types receive different attention weights during message passing.
Transaction edges carry more fraud signal than device-sharing edges.

**In Our System:**  
We implement this as explicit relation-type weights:
```python
relation_weights = {
    "COVERS":     0.40,   # material coverage = highest relevance signal
    "APPLIES_TO": 0.35,   # application match = strong signal
    "MENTIONS":   0.15,   # property mention = supporting signal
    "BELONGS_TO": 0.10,   # category match = weak signal
}
```
This is a simplified, interpretable version of attention-weighted aggregation.

---

#### 4. Multi-Stage Ranking

**In HETGNN-FR:**  
Candidate ring members are first retrieved (recall stage), then ranked by a
learned scoring function that combines node features, edge features, and graph
structure.

**In Our System:**  
We implement the same three-stage pipeline:
1. **Recall**: Dense FAISS retrieval (high recall, lower precision)
2. **Re-ranking**: BM25 scores added to boost keyword-exact matches
3. **Graph boost**: Entity neighbourhood matching for domain-specific signal

Final score fuses all three — analogous to HETGNN-FR's multi-signal ranking.

---

#### 5. Explainability

**In HETGNN-FR:**  
Fraud explanations identify which sub-graph path activated the detection
(e.g., "Account A shares Device X with known fraudster Account B").

**In Our System:**  
Each recommendation includes `matched_entities` — the specific material,
application, and property nodes that contributed to the graph match score.
The LLM rationale is grounded in these matched entities, providing a
human-readable explanation analogous to the paper's sub-graph evidence paths.

---

### What We Did NOT Adapt

- **Temporal dynamics**: HETGNN-FR processes time-stamped transaction sequences.
  Our graph is static (BIS standards don't change frequently). We drop temporality.
- **GNN message passing**: We use rule-based graph scoring instead of learned
  GNN parameters — appropriate for a hackathon prototype and more interpretable.
- **Fraud ring detection**: The clustering / community detection aspect is
  irrelevant to our domain. We use only the candidate-retrieval and ranking
  components of the paper's architecture.

---

### Citation Note

When presenting this work, cite HETGNN-FR as the architectural inspiration for:
- The choice to build a heterogeneous knowledge graph (Section 3.2 of the paper)
- The relation-type weighting scheme (analogous to Section 4.1)
- The multi-stage candidate-then-rank pipeline (Section 3.1)
- The evidence-grounded explainability approach (Section 5)
