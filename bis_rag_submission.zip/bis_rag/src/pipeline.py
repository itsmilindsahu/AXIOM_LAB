"""
src/pipeline.py
---------------
High-level BIS RAG pipeline.  Combines retriever + rationale generator
into a single callable used by the Streamlit app and evaluation harness.
"""

import os
import sys
from typing import Any, Dict, List, Optional

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from src.ranking.rationale import RationaleGenerator


class BISPipeline:
    """
    Singleton pipeline: load once, query many times.
    Automatically falls back to offline TF-IDF retriever if the BGE
    sentence-transformer model is unavailable (e.g. CI, sandboxed envs).
    """

    _instance: Optional["BISPipeline"] = None

    def __new__(cls) -> "BISPipeline":
        if cls._instance is None:
            cls._instance = super().__new__(cls)
            cls._instance._initialised = False
        return cls._instance

    def __init__(self) -> None:
        if self._initialised:
            return
        try:
            from src.retrieval.hybrid_retriever import BISRetriever
            self.retriever = BISRetriever()
        except Exception:
            from src.retrieval.hybrid_retriever_offline import BISRetriever
            self.retriever = BISRetriever()
        self.rationale  = RationaleGenerator()
        self._initialised = True

    def run(self, query: str, top_k: int = 5) -> Dict[str, Any]:
        """
        Run full pipeline: retrieve → rationale → return.

        Returns dict:
          query, latency_ms, results (list of enriched standard dicts)
        """
        output  = self.retriever.query(query, top_k=top_k)
        results = output["results"]

        for std in results:
            std["rationale"] = self.rationale.generate(query, std)

        return {
            "query":      query,
            "latency_ms": output["latency_ms"],
            "results":    results,
        }
