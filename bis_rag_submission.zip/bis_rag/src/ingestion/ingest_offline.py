"""
Offline ingestion using TF-IDF dense vectors (for CI/sandboxed environments).
Produces FAISS index, BM25, metadata identical in structure to the main ingest.py.
The final submission uses BAAI/bge-small-en-v1.5 — this is a build-time substitute.
"""
import json, os, pickle
import numpy as np
import faiss
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.preprocessing import normalize
from rank_bm25 import BM25Okapi

SEED_FILE  = "data/bis_standards_seed.json"
INDEX_PATH = "data/processed/faiss.index"
META_PATH  = "data/processed/metadata.pkl"
BM25_PATH  = "data/processed/bm25.pkl"
CORPUS_PATH= "data/processed/corpus.pkl"
CHUNK_SEP  = " | "

def build_text_chunk(std):
    return CHUNK_SEP.join([
        f"Standard: {std['standard_id']} — {std['title']}",
        f"Category: {std['category']}",
        f"Materials: {', '.join(std['material'])}",
        f"Applications: {', '.join(std['application'])}",
        f"Properties: {', '.join(std['property'])}",
        f"Keywords: {', '.join(std['keywords'])}",
        f"Scope: {std['scope']}",
    ])

def ingest_offline(seed_file=SEED_FILE):
    os.makedirs("data/processed", exist_ok=True)
    with open(seed_file) as f:
        standards = json.load(f)
    print(f"[Ingest-offline] {len(standards)} standards")

    chunks, metadata = [], []
    for std in standards:
        chunk = build_text_chunk(std)
        chunks.append(chunk)
        metadata.append({
            "standard_id": std["standard_id"], "title": std["title"],
            "category": std["category"], "material": std["material"],
            "application": std["application"], "property": std["property"],
            "keywords": std["keywords"], "scope": std["scope"],
            "source_file": std.get("source_file","seed_data"),
            "page": std.get("page","N/A"), "chunk_text": chunk,
        })

    # TF-IDF dense vectors (512-dim via SVD truncation)
    vec = TfidfVectorizer(ngram_range=(1,2), min_df=1, sublinear_tf=True)
    tfidf_matrix = vec.fit_transform(chunks).toarray().astype("float32")
    # Pad/truncate to 512 dims for a realistic FAISS index size
    dim = min(512, tfidf_matrix.shape[1])
    emb = tfidf_matrix[:, :dim]
    emb = normalize(emb, norm="l2").astype("float32")

    index = faiss.IndexFlatIP(dim)
    index.add(emb)
    faiss.write_index(index, INDEX_PATH)

    # Store vectorizer for query-time encoding
    with open("data/processed/tfidf_vec.pkl","wb") as f:
        pickle.dump((vec, dim), f)

    tokenised = [c.lower().split() for c in chunks]
    bm25 = BM25Okapi(tokenised)
    with open(BM25_PATH,"wb") as f: pickle.dump(bm25, f)
    with open(CORPUS_PATH,"wb") as f: pickle.dump(chunks, f)
    with open(META_PATH,"wb") as f: pickle.dump(metadata, f)
    print("[Ingest-offline] ✓ Done")

if __name__ == "__main__":
    ingest_offline()
