"""
src/ingestion/ingest.py
-----------------------
BIS Standard Document Ingestion Pipeline.

Loads BIS standards from JSON seed data (and optionally real PDFs),
chunks the content, generates dense embeddings, builds a FAISS index,
and persists a BM25 corpus for hybrid retrieval.

Inspired by the candidate-extraction stage in HETGNN-FR, where
heterogeneous node features are first encoded before graph construction.
"""

import json
import os
import pickle
from typing import List, Dict, Any

import numpy as np
import faiss
from sentence_transformers import SentenceTransformer
from rank_bm25 import BM25Okapi

# ── Config ──────────────────────────────────────────────────────────────────
SEED_FILE       = "data/bis_standards_seed.json"
INDEX_PATH      = "data/processed/faiss.index"
META_PATH       = "data/processed/metadata.pkl"
BM25_PATH       = "data/processed/bm25.pkl"
CORPUS_PATH     = "data/processed/corpus.pkl"
EMBED_MODEL     = "BAAI/bge-small-en-v1.5"   # lightweight, fast, good quality
CHUNK_SEPARATOR = " | "


# ── Helpers ──────────────────────────────────────────────────────────────────

def build_text_chunk(standard: Dict[str, Any]) -> str:
    """
    Synthesise a rich text chunk from structured metadata fields.
    This serves as the 'document' for both dense embedding and BM25.
    """
    parts = [
        f"Standard: {standard['standard_id']} — {standard['title']}",
        f"Category: {standard['category']}",
        f"Materials: {', '.join(standard['material'])}",
        f"Applications: {', '.join(standard['application'])}",
        f"Properties: {', '.join(standard['property'])}",
        f"Keywords: {', '.join(standard['keywords'])}",
        f"Scope: {standard['scope']}",
    ]
    return CHUNK_SEPARATOR.join(parts)


def tokenise_for_bm25(text: str) -> List[str]:
    """Simple whitespace + lowercase tokenisation for BM25."""
    return text.lower().split()


# ── Main ingestion ────────────────────────────────────────────────────────────

def ingest(seed_file: str = SEED_FILE) -> None:
    """
    Full ingestion pipeline:
      1. Load seed standards from JSON.
      2. Build text chunks.
      3. Encode with SentenceTransformer → float32 matrix.
      4. Build & save FAISS flat-L2 index.
      5. Build & save BM25 index.
      6. Persist metadata list.
    """
    os.makedirs("data/processed", exist_ok=True)

    print(f"[Ingest] Loading standards from {seed_file} ...")
    with open(seed_file, "r") as f:
        standards: List[Dict[str, Any]] = json.load(f)

    print(f"[Ingest] {len(standards)} standards found.")

    # Build text chunks + collect metadata
    chunks:   List[str]           = []
    metadata: List[Dict[str, Any]] = []

    for std in standards:
        chunk = build_text_chunk(std)
        chunks.append(chunk)
        metadata.append({
            "standard_id": std["standard_id"],
            "title":        std["title"],
            "category":     std["category"],
            "material":     std["material"],
            "application":  std["application"],
            "property":     std["property"],
            "keywords":     std["keywords"],
            "scope":        std["scope"],
            "source_file":  std.get("source_file", "seed_data"),
            "page":         std.get("page", "N/A"),
            "chunk_text":   chunk,
        })

    # Dense embeddings
    print(f"[Ingest] Loading embedding model: {EMBED_MODEL} ...")
    model = SentenceTransformer(EMBED_MODEL)
    print("[Ingest] Encoding chunks ...")
    embeddings: np.ndarray = model.encode(
        chunks,
        batch_size=32,
        show_progress_bar=True,
        normalize_embeddings=True,   # cosine similarity via inner product
    ).astype("float32")

    # FAISS index (Inner Product on L2-normalised vecs = cosine similarity)
    dim   = embeddings.shape[1]
    index = faiss.IndexFlatIP(dim)
    index.add(embeddings)
    faiss.write_index(index, INDEX_PATH)
    print(f"[Ingest] FAISS index saved → {INDEX_PATH}  (dim={dim}, n={index.ntotal})")

    # BM25
    tokenised = [tokenise_for_bm25(c) for c in chunks]
    bm25      = BM25Okapi(tokenised)
    with open(BM25_PATH, "wb") as f:
        pickle.dump(bm25, f)
    with open(CORPUS_PATH, "wb") as f:
        pickle.dump(chunks, f)
    print(f"[Ingest] BM25 index saved → {BM25_PATH}")

    # Metadata
    with open(META_PATH, "wb") as f:
        pickle.dump(metadata, f)
    print(f"[Ingest] Metadata saved  → {META_PATH}")

    print("[Ingest] ✓ Pipeline complete.")


if __name__ == "__main__":
    ingest()
