"""
src/retrieval/hybrid_retriever.py
----------------------------------
Hybrid Retrieval: Dense (FAISS) + Sparse (BM25) + Graph Boost.

Architecture mirrors the three-stage candidate ranking in HETGNN-FR:
  Stage 1 — Candidate extraction  : dense recall (FAISS top-k)
  Stage 2 — Sparse re-scoring     : BM25 keyword overlap
  Stage 3 — Graph-enhanced ranking : entity neighbourhood match

Final score formula (from the project spec):
  final_score = 0.50 * dense_sim + 0.25 * bm25_norm + 0.25 * graph_score
"""

import pickle
import time
from typing import Any, Dict, List, Tuple

import faiss
import numpy as np
from sentence_transformers import SentenceTransformer

from src.graph.knowledge_graph import (
    load_graph,
    extract_query_entities,
    compute_graph_match_score,
)

# ── Config ────────────────────────────────────────────────────────────────────
INDEX_PATH  = "data/processed/faiss.index"
META_PATH   = "data/processed/metadata.pkl"
BM25_PATH   = "data/processed/bm25.pkl"
CORPUS_PATH = "data/processed/corpus.pkl"
GRAPH_PATH  = "data/processed/knowledge_graph.pkl"
EMBED_MODEL = "BAAI/bge-small-en-v1.5"

DENSE_WEIGHT = 0.50
BM25_WEIGHT  = 0.25
GRAPH_WEIGHT = 0.25
TOP_K_DENSE  = 10   # initial FAISS recall pool
TOP_K_FINAL  = 5    # returned to user


# ── Retriever class ───────────────────────────────────────────────────────────

class BISRetriever:
    """
    Singleton-style retriever.  Load once, query many times.
    """

    def __init__(self) -> None:
        print("[Retriever] Loading FAISS index ...")
        self.index = faiss.read_index(INDEX_PATH)

        print("[Retriever] Loading metadata ...")
        with open(META_PATH, "rb") as f:
            self.metadata: List[Dict[str, Any]] = pickle.load(f)

        print("[Retriever] Loading BM25 index ...")
        with open(BM25_PATH, "rb") as f:
            self.bm25 = pickle.load(f)
        with open(CORPUS_PATH, "rb") as f:
            self.corpus: List[str] = pickle.load(f)

        print("[Retriever] Loading knowledge graph ...")
        self.graph = load_graph(GRAPH_PATH)

        print(f"[Retriever] Loading embedding model: {EMBED_MODEL} ...")
        self.model = SentenceTransformer(EMBED_MODEL)

        print("[Retriever] ✓ Ready.")

    # ── Internal helpers ──────────────────────────────────────────────────────

    def _dense_retrieve(self, query: str, top_k: int) -> List[Tuple[int, float]]:
        """Return (index, cosine_similarity) pairs from FAISS."""
        q_emb = self.model.encode(
            [query], normalize_embeddings=True
        ).astype("float32")
        scores, indices = self.index.search(q_emb, top_k)
        return list(zip(indices[0].tolist(), scores[0].tolist()))

    def _bm25_scores(self, query: str) -> np.ndarray:
        """Return raw BM25 scores for every document in corpus."""
        tokens = query.lower().split()
        return np.array(self.bm25.get_scores(tokens))

    @staticmethod
    def _normalise(arr: np.ndarray) -> np.ndarray:
        """Min-max normalise to [0, 1]."""
        mn, mx = arr.min(), arr.max()
        if mx - mn < 1e-9:
            return np.zeros_like(arr)
        return (arr - mn) / (mx - mn)

    # ── Public query interface ────────────────────────────────────────────────

    def query(
        self,
        query_text: str,
        top_k: int = TOP_K_FINAL,
    ) -> Dict[str, Any]:
        """
        Run the full three-stage pipeline and return ranked results.

        Returns
        -------
        dict with keys:
          results   : list of result dicts (see below)
          latency_ms: end-to-end latency in milliseconds
          query     : original query text
        """
        t0 = time.perf_counter()

        n_docs = len(self.metadata)

        # Stage 1 — Dense retrieval (FAISS)
        dense_hits = self._dense_retrieve(query_text, min(TOP_K_DENSE, n_docs))
        dense_dict: Dict[int, float] = dict(dense_hits)

        # Stage 2 — BM25 scores (all docs)
        bm25_raw    = self._bm25_scores(query_text)
        bm25_normed = self._normalise(bm25_raw)

        # Stage 3 — Graph entity extraction
        query_entities = extract_query_entities(query_text)

        # Candidates = union of FAISS top-k and BM25 top-k
        bm25_top_idx = np.argsort(bm25_raw)[::-1][:TOP_K_DENSE].tolist()
        candidate_ids: List[int] = list(
            set(dense_dict.keys()) | set(bm25_top_idx)
        )

        scored: List[Dict[str, Any]] = []

        for idx in candidate_ids:
            if idx < 0 or idx >= n_docs:
                continue

            meta           = self.metadata[idx]
            std_id         = meta["standard_id"]
            dense_sim      = dense_dict.get(idx, 0.0)
            bm25_score     = float(bm25_normed[idx])
            graph_score, matched_ents = compute_graph_match_score(
                self.graph, std_id, query_entities
            )

            final_score = (
                DENSE_WEIGHT  * dense_sim
                + BM25_WEIGHT  * bm25_score
                + GRAPH_WEIGHT * graph_score
            )

            scored.append({
                "standard_id":     std_id,
                "title":           meta["title"],
                "category":        meta["category"],
                "scope":           meta["scope"],
                "source_file":     meta["source_file"],
                "page":            meta["page"],
                "chunk_text":      meta["chunk_text"],
                "confidence":      round(float(final_score), 4),
                "dense_sim":       round(float(dense_sim), 4),
                "bm25_score":      round(float(bm25_score), 4),
                "graph_score":     round(float(graph_score), 4),
                "matched_entities": matched_ents,
                "material":        meta["material"],
                "application":     meta["application"],
                "keywords":        meta["keywords"],
            })

        # Sort by final score descending
        scored.sort(key=lambda x: x["confidence"], reverse=True)
        results = scored[:top_k]

        latency_ms = round((time.perf_counter() - t0) * 1000, 1)

        return {
            "query":      query_text,
            "results":    results,
            "latency_ms": latency_ms,
        }
