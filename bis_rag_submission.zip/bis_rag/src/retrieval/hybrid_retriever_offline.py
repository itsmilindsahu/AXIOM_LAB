"""
Offline retriever using TF-IDF vectors instead of BGE embeddings.
Drop-in replacement for evaluation in sandboxed environments.
"""
import pickle, time
from typing import Any, Dict, List, Tuple
import faiss, numpy as np
from sklearn.preprocessing import normalize
from src.graph.knowledge_graph import load_graph, extract_query_entities, compute_graph_match_score

INDEX_PATH  = "data/processed/faiss.index"
META_PATH   = "data/processed/metadata.pkl"
BM25_PATH   = "data/processed/bm25.pkl"
CORPUS_PATH = "data/processed/corpus.pkl"
GRAPH_PATH  = "data/processed/knowledge_graph.pkl"
TFIDF_PATH  = "data/processed/tfidf_vec.pkl"

DENSE_WEIGHT = 0.50
BM25_WEIGHT  = 0.25
GRAPH_WEIGHT = 0.25
TOP_K_DENSE  = 10
TOP_K_FINAL  = 5

class BISRetriever:
    _instance = None
    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
            cls._instance._initialised = False
        return cls._instance

    def __init__(self):
        if self._initialised: return
        self.index    = faiss.read_index(INDEX_PATH)
        with open(META_PATH,"rb") as f:   self.metadata = pickle.load(f)
        with open(BM25_PATH,"rb") as f:   self.bm25     = pickle.load(f)
        with open(CORPUS_PATH,"rb") as f: self.corpus   = pickle.load(f)
        with open(TFIDF_PATH,"rb") as f:  self.vec, self.dim = pickle.load(f)
        self.graph    = load_graph(GRAPH_PATH)
        self._initialised = True

    def _encode(self, text):
        mat = self.vec.transform([text]).toarray().astype("float32")
        emb = mat[:, :self.dim]
        return normalize(emb, norm="l2").astype("float32")

    def _dense_retrieve(self, query, top_k):
        q = self._encode(query)
        scores, indices = self.index.search(q, top_k)
        return list(zip(indices[0].tolist(), scores[0].tolist()))

    def _bm25_scores(self, query):
        return np.array(self.bm25.get_scores(query.lower().split()))

    @staticmethod
    def _normalise(arr):
        mn, mx = arr.min(), arr.max()
        if mx - mn < 1e-9: return np.zeros_like(arr)
        return (arr - mn) / (mx - mn)

    def query(self, query_text, top_k=TOP_K_FINAL):
        t0 = time.perf_counter()
        n_docs = len(self.metadata)
        dense_hits = self._dense_retrieve(query_text, min(TOP_K_DENSE, n_docs))
        dense_dict = dict(dense_hits)
        bm25_raw   = self._bm25_scores(query_text)
        bm25_normed= self._normalise(bm25_raw)
        query_ents = extract_query_entities(query_text)
        bm25_top   = np.argsort(bm25_raw)[::-1][:TOP_K_DENSE].tolist()
        candidates = list(set(dense_dict.keys()) | set(bm25_top))

        scored = []
        for idx in candidates:
            if idx < 0 or idx >= n_docs: continue
            meta = self.metadata[idx]; sid = meta["standard_id"]
            dense_sim  = dense_dict.get(idx, 0.0)
            bm25_score = float(bm25_normed[idx])
            graph_score, matched = compute_graph_match_score(self.graph, sid, query_ents)
            final = DENSE_WEIGHT*dense_sim + BM25_WEIGHT*bm25_score + GRAPH_WEIGHT*graph_score
            scored.append({
                "standard_id": sid, "title": meta["title"], "category": meta["category"],
                "scope": meta["scope"], "source_file": meta["source_file"], "page": meta["page"],
                "chunk_text": meta["chunk_text"], "confidence": round(float(final),4),
                "dense_sim": round(float(dense_sim),4), "bm25_score": round(float(bm25_score),4),
                "graph_score": round(float(graph_score),4), "matched_entities": matched,
                "material": meta["material"], "application": meta["application"],
                "keywords": meta["keywords"],
            })
        scored.sort(key=lambda x: x["confidence"], reverse=True)
        return {"query": query_text, "results": scored[:top_k],
                "latency_ms": round((time.perf_counter()-t0)*1000, 1)}
