"""
src/ranking/rationale.py
------------------------
LLM-based rationale generation for each recommended BIS standard.

Design principle (from HETGNN-FR's explainability layer):
  The LLM is only allowed to reason over retrieved evidence.
  It must NOT fabricate standard IDs, titles, or clauses.
  Each explanation cites the matched material/application and the
  supporting chunk — analogous to the sub-graph evidence paths
  used for fraud-ring explanations in the paper.
"""

import os
from typing import Any, Dict, List

ANTHROPIC_KEY_ENV = "ANTHROPIC_API_KEY"

# ── Prompt template ───────────────────────────────────────────────────────────

RATIONALE_SYSTEM = """You are an expert BIS (Bureau of Indian Standards) compliance assistant.
Your task is to explain WHY a specific BIS standard is relevant to a given product description.

Rules:
1. Only use information from the provided standard metadata and retrieved chunk.
2. Do NOT invent standard IDs, clauses, or requirements not present in the context.
3. Keep the rationale concise (3-4 sentences).
4. Mention: (a) what material/application matched, (b) what the standard covers, (c) why the MSE should comply.
5. Write in plain English suitable for a small business owner."""


def build_rationale_prompt(
    query:    str,
    standard: Dict[str, Any],
) -> str:
    return f"""Product description: "{query}"

BIS Standard matched:
  ID       : {standard['standard_id']}
  Title    : {standard['title']}
  Category : {standard['category']}
  Scope    : {standard['scope']}
  Materials covered: {', '.join(standard['material'][:5])}
  Applications    : {', '.join(standard['application'][:5])}
  Matched entities: {', '.join(standard.get('matched_entities', [])[:8])}
  Retrieved chunk  : {standard['chunk_text'][:400]}

In 3-4 sentences, explain why this standard applies to the product described above."""


# ── Rationale generator ───────────────────────────────────────────────────────

class RationaleGenerator:
    """
    Generates LLM rationale for each recommended standard.
    Falls back to a deterministic template if no API key is present.
    """

    def __init__(self) -> None:
        self.api_key = os.environ.get(ANTHROPIC_KEY_ENV, "")
        self.client  = None
        if self.api_key:
            try:
                import anthropic
                self.client = anthropic.Anthropic(api_key=self.api_key)
                print("[Rationale] Using Claude API for rationale generation.")
            except ImportError:
                print("[Rationale] anthropic package not installed — using template fallback.")
        else:
            print("[Rationale] No ANTHROPIC_API_KEY found — using template fallback.")

    def generate(self, query: str, standard: Dict[str, Any]) -> str:
        if self.client:
            return self._llm_rationale(query, standard)
        return self._template_rationale(query, standard)

    def generate_batch(
        self, query: str, standards: List[Dict[str, Any]]
    ) -> List[str]:
        return [self.generate(query, s) for s in standards]

    # ── LLM path ──────────────────────────────────────────────────────────────

    def _llm_rationale(self, query: str, standard: Dict[str, Any]) -> str:
        try:
            msg = self.client.messages.create(
                model="claude-haiku-4-5-20251001",
                max_tokens=256,
                system=RATIONALE_SYSTEM,
                messages=[
                    {"role": "user", "content": build_rationale_prompt(query, standard)},
                ],
            )
            return msg.content[0].text.strip()
        except Exception as exc:
            return self._template_rationale(query, standard) + f" [LLM error: {exc}]"

    # ── Template fallback ──────────────────────────────────────────────────────

    @staticmethod
    def _template_rationale(query: str, standard: Dict[str, Any]) -> str:
        mats = ", ".join(standard["material"][:3])
        apps = ", ".join(standard["application"][:2])
        ents = ", ".join(standard.get("matched_entities", [])[:4]) or "relevant entities"
        return (
            f"{standard['standard_id']} — {standard['title']} — is applicable because "
            f"the product description references {ents}, which directly aligns with this "
            f"standard's coverage of {mats}. "
            f"The standard governs {apps} and defines requirements for quality, "
            f"testing, and performance that any MSE supplying or using this material must meet. "
            f"Compliance ensures product safety, regulatory acceptance, and market credibility."
        )
