"""
src/graph/knowledge_graph.py
-----------------------------
Lightweight Knowledge Graph for BIS Standard Discovery.

Inspired directly by HETGNN-FR's heterogeneous graph construction
where entities (accounts, merchants, devices) become typed nodes and
relationships become typed edges enabling cross-entity reasoning.

Here we model:
  Nodes  : Product | Material | Application | Property | BISStandard
  Edges  : HAS_MATERIAL | USED_FOR | COVERS | APPLIES_TO | MENTIONS | BELONGS_TO

The graph is used at query time to compute a graph_match_score that
boosts standards whose entity neighbourhood overlaps with the query.
"""

import json
import pickle
from typing import Dict, List, Any, Tuple, Set

import networkx as nx

# ── Paths ────────────────────────────────────────────────────────────────────
META_PATH   = "data/processed/metadata.pkl"
GRAPH_PATH  = "data/processed/knowledge_graph.pkl"
SEED_FILE   = "data/bis_standards_seed.json"


# ── Node / Edge type constants ────────────────────────────────────────────────
class NodeType:
    STANDARD    = "BISStandard"
    MATERIAL    = "Material"
    APPLICATION = "Application"
    PROPERTY    = "Property"
    CATEGORY    = "Category"


class EdgeType:
    COVERS      = "COVERS"
    APPLIES_TO  = "APPLIES_TO"
    MENTIONS    = "MENTIONS"
    BELONGS_TO  = "BELONGS_TO"


# ── Graph Builder ─────────────────────────────────────────────────────────────

def build_graph(seed_file: str = SEED_FILE) -> nx.MultiDiGraph:
    """
    Construct a heterogeneous directed multigraph from BIS seed data.

    Node attributes carry a 'type' field (NodeType.*).
    Edge attributes carry a 'relation' field (EdgeType.*).

    This mirrors HETGNN-FR's construction of typed subgraphs where
    different entity types play structurally distinct roles.
    """
    G = nx.MultiDiGraph()

    with open(seed_file, "r") as f:
        standards: List[Dict[str, Any]] = json.load(f)

    for std in standards:
        sid   = std["standard_id"]
        title = std["title"]

        # ── Standard node ──────────────────────────────────────────────────
        G.add_node(sid, type=NodeType.STANDARD, title=title,
                   category=std["category"], scope=std["scope"])

        # ── Category node ──────────────────────────────────────────────────
        cat = std["category"]
        if not G.has_node(cat):
            G.add_node(cat, type=NodeType.CATEGORY)
        G.add_edge(sid, cat, relation=EdgeType.BELONGS_TO)

        # ── Material nodes ──────────────────────────────────────────────────
        for mat in std["material"]:
            mat_id = f"mat::{mat.lower().strip()}"
            if not G.has_node(mat_id):
                G.add_node(mat_id, type=NodeType.MATERIAL, label=mat)
            G.add_edge(sid, mat_id, relation=EdgeType.COVERS)

        # ── Application nodes ───────────────────────────────────────────────
        for app in std["application"]:
            app_id = f"app::{app.lower().strip()}"
            if not G.has_node(app_id):
                G.add_node(app_id, type=NodeType.APPLICATION, label=app)
            G.add_edge(sid, app_id, relation=EdgeType.APPLIES_TO)

        # ── Property nodes ──────────────────────────────────────────────────
        for prop in std["property"]:
            prop_id = f"prop::{prop.lower().strip()}"
            if not G.has_node(prop_id):
                G.add_node(prop_id, type=NodeType.PROPERTY, label=prop)
            G.add_edge(sid, prop_id, relation=EdgeType.MENTIONS)

    print(f"[Graph] Built graph: {G.number_of_nodes()} nodes, "
          f"{G.number_of_edges()} edges")
    return G


def save_graph(G: nx.MultiDiGraph, path: str = GRAPH_PATH) -> None:
    with open(path, "wb") as f:
        pickle.dump(G, f)
    print(f"[Graph] Graph saved → {path}")


def load_graph(path: str = GRAPH_PATH) -> nx.MultiDiGraph:
    with open(path, "rb") as f:
        return pickle.load(f)


# ── Query-time graph matching ──────────────────────────────────────────────────

def extract_query_entities(query: str) -> Dict[str, Set[str]]:
    """
    Extract material, application, and property tokens from a free-text query
    using simple keyword matching against known graph node labels.

    In HETGNN-FR this corresponds to the candidate extraction step where
    seed nodes are identified before neighbourhood aggregation.
    """
    query_lower = query.lower()
    tokens      = set(query_lower.split())

    # Augmented synonym map (materials & applications)
    synonyms: Dict[str, str] = {
        "tmt": "tmt bars", "rebar": "reinforcement steel",
        "rcc": "RCC construction", "concrete": "concrete",
        "cement": "cement", "opc": "ordinary portland cement",
        "ppc": "pozzolana cement", "psc": "slag cement",
        "aggregate": "coarse aggregate", "sand": "fine aggregate",
        "admixture": "admixture", "rmc": "ready mix concrete",
        "mix": "mix design", "m20": "mix design", "m25": "mix design",
        "m30": "mix design", "steel": "steel", "bar": "TMT bars",
        "fly ash": "pozzolana", "slag": "slag",
        "superplasticizer": "superplasticizer",
    }

    matched: Dict[str, Set[str]] = {
        NodeType.MATERIAL:    set(),
        NodeType.APPLICATION: set(),
        NodeType.PROPERTY:    set(),
    }

    for kw, canonical in synonyms.items():
        if kw in query_lower:
            matched[NodeType.MATERIAL].add(canonical.lower())

    # Also add raw tokens as potential matches
    for tok in tokens:
        if len(tok) > 3:
            matched[NodeType.MATERIAL].add(tok)
            matched[NodeType.APPLICATION].add(tok)

    return matched


def compute_graph_match_score(
    G:          nx.MultiDiGraph,
    standard_id: str,
    query_entities: Dict[str, Set[str]],
) -> Tuple[float, List[str]]:
    """
    Compute how strongly a standard's graph neighbourhood overlaps
    with the entities extracted from the query.

    Returns (score ∈ [0,1], list of matched entity labels).

    Inspired by HETGNN-FR's edge-weighted aggregation across heterogeneous
    neighbourhoods, but simplified for the hackathon prototype.
    """
    if not G.has_node(standard_id):
        return 0.0, []

    matched_labels: List[str] = []
    total_weight               = 0.0

    # Weights per relation type (mirrors attention in HETGNN-FR)
    relation_weights = {
        EdgeType.COVERS:     0.40,   # material match is highest signal
        EdgeType.APPLIES_TO: 0.35,   # application match
        EdgeType.MENTIONS:   0.15,   # property match
        EdgeType.BELONGS_TO: 0.10,   # category match
    }

    for _, neighbour, data in G.out_edges(standard_id, data=True):
        relation = data.get("relation", "")
        weight   = relation_weights.get(relation, 0.05)
        node_data = G.nodes[neighbour]
        label = str(node_data.get("label", neighbour)).lower()

        ntype = node_data.get("type", "")
        query_set = query_entities.get(ntype, set())

        # Check if any query entity is a substring of or matches the node label
        hit = any(
            ent in label or label in ent
            for ent in query_set
            if len(ent) > 2
        )

        if hit:
            total_weight    += weight
            matched_labels.append(node_data.get("label", neighbour))

    # Normalise to [0, 1] (max possible weight ≈ 1.0 if all edges matched)
    score = min(total_weight, 1.0)
    return round(score, 4), list(set(matched_labels))


if __name__ == "__main__":
    import os
    os.makedirs("data/processed", exist_ok=True)
    G = build_graph()
    save_graph(G)
    print("\nNode types:")
    for ntype in [NodeType.STANDARD, NodeType.MATERIAL, NodeType.APPLICATION]:
        count = sum(1 for _, d in G.nodes(data=True) if d.get("type") == ntype)
        print(f"  {ntype}: {count}")
