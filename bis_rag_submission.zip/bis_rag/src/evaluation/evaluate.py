"""
src/evaluation/evaluate.py
---------------------------
Evaluation harness for the BIS Standard Discovery retrieval pipeline.

Metrics (aligned with standard IR evaluation):
  - Hit Rate @ K   : fraction of queries where at least 1 relevant standard is in top-K
  - MRR @ K        : Mean Reciprocal Rank
  - Precision @ K  : fraction of top-K results that are relevant
  - Average latency

Supports ablation modes: --mode [hybrid|dense_only|bm25_only|graph_only]
Run: python src/evaluation/evaluate.py
     python src/evaluation/evaluate.py --adversarial
"""

import json
import time
import argparse
from typing import Any, Callable, Dict, List, Optional


# ── Golden test set (35 queries: 30 in-distribution + 5 adversarial) ─────────

GOLDEN_TEST_SET: List[Dict[str, Any]] = [
    # Cement
    {"query": "OPC cement for general building construction",
     "relevant": ["IS 269", "IS 8112"], "category": "cement"},
    {"query": "43 grade ordinary portland cement for structural concrete",
     "relevant": ["IS 8112", "IS 456"], "category": "cement"},
    {"query": "53 grade cement for high-rise buildings",
     "relevant": ["IS 12269", "IS 8112"], "category": "cement"},
    {"query": "portland pozzolana cement with fly ash",
     "relevant": ["IS 1489", "IS 3812"], "category": "cement"},
    {"query": "portland slag cement for marine structures",
     "relevant": ["IS 455", "IS 12089"], "category": "cement"},
    {"query": "blended cement for mass concrete dam construction",
     "relevant": ["IS 1489", "IS 455"], "category": "cement"},
    {"query": "cement fineness soundness and setting time test methods",
     "relevant": ["IS 4031", "IS 269"], "category": "cement"},
    # Steel
    {"query": "TMT steel bars for RCC construction",
     "relevant": ["IS 1786", "IS 456"], "category": "steel"},
    {"query": "Fe500 grade deformed steel bars for columns and beams",
     "relevant": ["IS 1786", "IS 456"], "category": "steel"},
    {"query": "high strength deformed bars for bridge construction",
     "relevant": ["IS 1786", "IS 1343"], "category": "steel"},
    {"query": "mild steel bars for lightly loaded RCC slabs",
     "relevant": ["IS 432", "IS 1786"], "category": "steel"},
    {"query": "Fe415 TMT rebar for residential construction",
     "relevant": ["IS 1786", "IS 456"], "category": "steel"},
    {"query": "steel reinforcement for concrete structures",
     "relevant": ["IS 1786", "IS 432", "IS 456"], "category": "steel"},
    {"query": "welded wire mesh for slab reinforcement",
     "relevant": ["IS 1566", "IS 456"], "category": "steel"},
    # Aggregates
    {"query": "coarse aggregate for structural concrete mix",
     "relevant": ["IS 383", "IS 456"], "category": "aggregate"},
    {"query": "fine aggregate sand for concrete production",
     "relevant": ["IS 383", "IS 10262"], "category": "aggregate"},
    {"query": "graded crushed stone aggregate for M30 concrete",
     "relevant": ["IS 383", "IS 10262", "IS 456"], "category": "aggregate"},
    {"query": "aggregate grading zones for concrete mix design",
     "relevant": ["IS 383", "IS 10262"], "category": "aggregate"},
    {"query": "aggregate flakiness elongation impact crushing value test",
     "relevant": ["IS 2386", "IS 383"], "category": "aggregate"},
    # Concrete
    {"query": "plain and reinforced concrete code of practice",
     "relevant": ["IS 456", "IS 10262"], "category": "concrete"},
    {"query": "M25 concrete mix design for structural use",
     "relevant": ["IS 10262", "IS 456"], "category": "concrete"},
    {"query": "concrete mix proportioning guidelines",
     "relevant": ["IS 10262", "IS 456"], "category": "concrete"},
    {"query": "ready mixed concrete for infrastructure project",
     "relevant": ["IS 4926", "IS 456"], "category": "concrete"},
    {"query": "RMC batching plant delivery for large pour",
     "relevant": ["IS 4926", "IS 10262"], "category": "concrete"},
    {"query": "self-compacting concrete with superplasticizer",
     "relevant": ["IS 9103", "IS 10262", "IS 456"], "category": "concrete"},
    {"query": "concrete cube compressive strength test method",
     "relevant": ["IS 516", "IS 456"], "category": "concrete"},
    # Admixtures
    {"query": "superplasticizer admixture for workable concrete",
     "relevant": ["IS 9103", "IS 10262"], "category": "admixture"},
    {"query": "chemical admixture retarder for hot weather concreting",
     "relevant": ["IS 9103", "IS 7861"], "category": "admixture"},
    {"query": "water reducing admixture for pumped concrete",
     "relevant": ["IS 9103", "IS 10262"], "category": "admixture"},
    # Multi-standard
    {"query": "structural concrete with OPC cement and TMT steel",
     "relevant": ["IS 456", "IS 1786", "IS 269"], "category": "multi"},
    {"query": "RCC foundation using 43 grade cement and Fe500 bars",
     "relevant": ["IS 8112", "IS 1786", "IS 456"], "category": "multi"},
    {"query": "ready mix concrete using PPC cement and admixture",
     "relevant": ["IS 4926", "IS 1489", "IS 9103"], "category": "multi"},
    {"query": "concrete grade M20 with fine and coarse aggregate",
     "relevant": ["IS 383", "IS 10262", "IS 456"], "category": "multi"},
    {"query": "building material compliance for MSE construction firm",
     "relevant": ["IS 456", "IS 1786", "IS 269", "IS 383"], "category": "multi"},
    {"query": "hot weather concreting with retarder and slump retention",
     "relevant": ["IS 7861", "IS 9103"], "category": "multi"},
]

ADVERSARIAL_TEST_SET: List[Dict[str, Any]] = [
    {"query": "fly ash brick for load bearing wall construction",
     "relevant": ["IS 2950"], "category": "adversarial"},
    {"query": "hollow concrete block for compound wall",
     "relevant": ["IS 2185"], "category": "adversarial"},
    {"query": "GGBS ground granulated blast furnace slag for sulfate soil",
     "relevant": ["IS 12089", "IS 455"], "category": "adversarial"},
    {"query": "ductile detailing of beam column joint in seismic zone 4",
     "relevant": ["IS 13920", "IS 1893"], "category": "adversarial"},
    {"query": "slump test for fresh concrete workability on site",
     "relevant": ["IS 516 Part 2", "IS 456"], "category": "adversarial"},
]


# ── Metric functions ──────────────────────────────────────────────────────────

def hit_at_k(retrieved: List[str], relevant: List[str], k: int) -> int:
    return int(any(r in retrieved[:k] for r in relevant))

def mrr_at_k(retrieved: List[str], relevant: List[str], k: int) -> float:
    for rank, sid in enumerate(retrieved[:k], start=1):
        if sid in relevant:
            return 1.0 / rank
    return 0.0

def precision_at_k(retrieved: List[str], relevant: List[str], k: int) -> float:
    top_k = retrieved[:k]
    hits  = sum(1 for r in top_k if r in relevant)
    return hits / k if k > 0 else 0.0


# ── Main evaluator ────────────────────────────────────────────────────────────

def evaluate_retriever(
    retrieve_fn: Callable[[str], Dict[str, Any]],
    test_set:    Optional[List[Dict[str, Any]]] = None,
    k_hit:       int  = 3,
    k_mrr:       int  = 5,
    k_prec:      int  = 5,
    verbose:     bool = True,
    set_label:   str  = "Main",
) -> Dict[str, Any]:
    if test_set is None:
        test_set = GOLDEN_TEST_SET

    hits, rrs, precs, latencies = [], [], [], []
    per_query = []

    if verbose:
        print(f"\n{'─'*70}")
        print(f"  Evaluation: {set_label}  ({len(test_set)} queries)")
        print(f"{'─'*70}")

    for i, item in enumerate(test_set, start=1):
        q = item["query"]; relevant = item["relevant"]; cat = item.get("category","")
        t0 = time.perf_counter()
        output = retrieve_fn(q)
        elapsed = (time.perf_counter() - t0) * 1000
        retrieved = [r["standard_id"] for r in output.get("results", [])]
        latency   = output.get("latency_ms", elapsed)

        h = hit_at_k(retrieved, relevant, k_hit)
        r = mrr_at_k(retrieved, relevant, k_mrr)
        p = precision_at_k(retrieved, relevant, k_prec)
        hits.append(h); rrs.append(r); precs.append(p); latencies.append(latency)

        row = {"query": q, "category": cat, "relevant": relevant,
               "retrieved": retrieved, "hit": h, "rr": round(r,4),
               "precision": round(p,4), "latency_ms": round(latency,1)}
        per_query.append(row)

        if verbose:
            status = "✓" if h else "✗"
            print(f"  [{i:02d}] {status}  HR={h}  RR={r:.3f}  P@{k_prec}={p:.3f}"
                  f"  {latency:5.0f}ms  [{cat}] {q[:50]}")

    n = len(test_set)
    metrics = {
        f"Hit_Rate@{k_hit}":   round(sum(hits)/n, 4),
        f"MRR@{k_mrr}":        round(sum(rrs)/n,  4),
        f"Precision@{k_prec}": round(sum(precs)/n, 4),
        "avg_latency_ms":      round(sum(latencies)/n, 1),
        "max_latency_ms":      round(max(latencies), 1),
        "n_queries":           n,
    }

    if verbose:
        print(f"\n{'='*70}")
        print(f"  RESULTS — {set_label}")
        print(f"{'='*70}")
        for k, v in metrics.items():
            print(f"  {k:<25} {v}")
        print(f"{'='*70}")

    return {"metrics": metrics, "per_query": per_query}


# ── Ablation wrapper ──────────────────────────────────────────────────────────

def make_ablation_retriever(base_retriever, mode: str):
    """Zero out selected score components for ablation studies."""
    import numpy as np
    from src.graph.knowledge_graph import extract_query_entities, compute_graph_match_score

    def retrieve_fn(query_text: str, top_k: int = 5):
        import time
        t0     = time.perf_counter()
        n_docs = len(base_retriever.metadata)

        q_emb = base_retriever._encode(query_text)
        d_scores, d_indices = base_retriever.index.search(q_emb, min(10, n_docs))
        dense_dict = dict(zip(d_indices[0].tolist(), d_scores[0].tolist()))

        bm25_raw    = base_retriever._bm25_scores(query_text)
        bm25_normed = base_retriever._normalise(bm25_raw)
        query_ents  = extract_query_entities(query_text)
        bm25_top    = np.argsort(bm25_raw)[::-1][:10].tolist()
        candidates  = list(set(dense_dict.keys()) | set(bm25_top))

        scored = []
        for idx in candidates:
            if idx < 0 or idx >= n_docs: continue
            meta = base_retriever.metadata[idx]; sid = meta["standard_id"]
            ds   = dense_dict.get(idx, 0.0)
            bs   = float(bm25_normed[idx])
            gs, matched = compute_graph_match_score(base_retriever.graph, sid, query_ents)

            if   mode == "dense_only":  final = float(ds)
            elif mode == "bm25_only":   final = float(bs)
            elif mode == "graph_only":  final = float(gs)
            else:                       final = 0.50*ds + 0.25*bs + 0.25*gs

            scored.append({"standard_id": sid, "title": meta["title"],
                            "confidence": round(float(final),4),
                            "dense_sim": round(float(ds),4),
                            "bm25_score": round(float(bs),4),
                            "graph_score": round(float(gs),4),
                            "matched_entities": matched})

        scored.sort(key=lambda x: x["confidence"], reverse=True)
        return {"query": query_text, "results": scored[:top_k],
                "latency_ms": round((time.perf_counter()-t0)*1000, 1)}

    return retrieve_fn


# ── CLI ───────────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    import sys, os
    sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "../..")))

    parser = argparse.ArgumentParser(description="BIS RAG Evaluation")
    parser.add_argument("--mode",
                        choices=["hybrid","dense_only","bm25_only","graph_only"],
                        default="hybrid")
    parser.add_argument("--adversarial", action="store_true")
    args = parser.parse_args()

    try:
        from src.retrieval.hybrid_retriever import BISRetriever
        retriever = BISRetriever()
        print("[Eval] Using BGE sentence-transformer retriever")
    except Exception:
        from src.retrieval.hybrid_retriever_offline import BISRetriever
        retriever = BISRetriever()
        print("[Eval] Using offline TF-IDF retriever (BGE unavailable)")

    retrieve_fn = make_ablation_retriever(retriever, args.mode)
    main_results = evaluate_retriever(
        retrieve_fn, GOLDEN_TEST_SET, verbose=True,
        set_label=f"Main [{args.mode}]")

    adv_results = None
    if args.adversarial:
        adv_results = evaluate_retriever(
            retrieve_fn, ADVERSARIAL_TEST_SET, verbose=True,
            set_label=f"Adversarial [{args.mode}]")

    ablation_table = None
    if args.mode == "hybrid":
        print("\n" + "="*70)
        print("  ABLATION COMPARISON")
        print("="*70)
        print(f"  {'Mode':<15} {'HR@3':>7} {'MRR@5':>7} {'P@5':>7} {'Lat(ms)':>9}")
        print(f"  {'─'*14} {'─'*7} {'─'*7} {'─'*7} {'─'*9}")
        ablation_table = {}
        for m in ["dense_only", "bm25_only", "hybrid"]:
            fn  = make_ablation_retriever(retriever, m)
            res = evaluate_retriever(fn, GOLDEN_TEST_SET, verbose=False, set_label=m)
            mt  = res["metrics"]
            ablation_table[m] = mt
            print(f"  {m:<15} {mt['Hit_Rate@3']:>7.4f} {mt['MRR@5']:>7.4f} "
                  f"{mt['Precision@5']:>7.4f} {mt['avg_latency_ms']:>9.1f}")
        print("="*70)

    os.makedirs("data/processed", exist_ok=True)
    out = {"mode": args.mode, "main": main_results,
           "adversarial": adv_results, "ablation": ablation_table}
    out_path = "data/processed/eval_results.json"
    with open(out_path, "w") as f:
        json.dump(out, f, indent=2)
    print(f"\nResults saved → {out_path}")
