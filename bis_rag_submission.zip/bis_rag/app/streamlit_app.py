"""
app/streamlit_app.py
---------------------
BIS Standard Discovery — Graph-Enhanced RAG Demo
Research-paper inspired UI: clean serif typography, structured layout,
citation-style result cards, confidence score bars, entity tags.
"""

import os
import sys
import time

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

import streamlit as st

# ── Page config ───────────────────────────────────────────────────────────────
st.set_page_config(
    page_title="BIS Standard Discovery — HETGNN-RAG",
    page_icon="📐",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ── Custom CSS: research paper aesthetic ────────────────────────────────────
st.markdown("""
<style>
/* ── Fonts ── */
@import url('https://fonts.googleapis.com/css2?family=Crimson+Pro:ital,wght@0,300;0,400;0,600;1,400&family=Source+Sans+3:wght@300;400;600&family=Source+Code+Pro:wght@400;600&display=swap');

/* ── Root palette ── */
:root {
  --paper-bg:      #faf9f6;
  --column-bg:     #ffffff;
  --rule-color:    #c8c0b0;
  --text-primary:  #1a1a18;
  --text-secondary:#4a4a44;
  --text-muted:    #7a7a74;
  --accent-blue:   #1a3a5c;
  --accent-red:    #8b1a1a;
  --accent-green:  #1a5c2a;
  --accent-amber:  #8b5a1a;
  --tag-bg:        #eef2f7;
  --tag-border:    #b8c8d8;
  --card-border:   #d8d0c0;
  --score-track:   #e8e4dc;
  --font-serif:    'Crimson Pro', Georgia, 'Times New Roman', serif;
  --font-sans:     'Source Sans 3', 'Helvetica Neue', sans-serif;
  --font-mono:     'Source Code Pro', 'Courier New', monospace;
}

/* ── Global reset ── */
html, body, [data-testid="stAppViewContainer"] {
  background-color: var(--paper-bg) !important;
  font-family: var(--font-sans);
}

[data-testid="stAppViewContainer"] > .main {
  background-color: var(--paper-bg);
}

/* ── Hide default Streamlit chrome ── */
#MainMenu, footer, header { visibility: hidden; }
[data-testid="stToolbar"] { display: none; }

/* ── Sidebar ── */
[data-testid="stSidebar"] {
  background-color: #f4f2ed !important;
  border-right: 1px solid var(--rule-color);
}

[data-testid="stSidebar"] * {
  font-family: var(--font-sans) !important;
  color: var(--text-primary) !important;
}

/* ── Main content wrapper ── */
.block-container {
  max-width: 1100px !important;
  padding: 2rem 3rem !important;
}

/* ── Journal header ── */
.journal-header {
  border-top: 3px double var(--accent-blue);
  border-bottom: 1px solid var(--rule-color);
  padding: 1.2rem 0 1rem;
  margin-bottom: 0.5rem;
}
.journal-name {
  font-family: var(--font-sans);
  font-size: 0.7rem;
  font-weight: 600;
  letter-spacing: 0.18em;
  text-transform: uppercase;
  color: var(--accent-blue);
}
.paper-title {
  font-family: var(--font-serif);
  font-size: 1.9rem;
  font-weight: 600;
  color: var(--text-primary);
  line-height: 1.25;
  margin: 0.3rem 0 0.2rem;
}
.paper-subtitle {
  font-family: var(--font-serif);
  font-size: 1.05rem;
  font-style: italic;
  color: var(--text-secondary);
  margin-bottom: 0.2rem;
}
.paper-meta {
  font-family: var(--font-sans);
  font-size: 0.72rem;
  color: var(--text-muted);
  letter-spacing: 0.04em;
}

/* ── Abstract box ── */
.abstract-box {
  border-left: 3px solid var(--accent-blue);
  background: #f0f4f8;
  padding: 0.9rem 1.2rem;
  margin: 1rem 0;
  border-radius: 0 4px 4px 0;
}
.abstract-label {
  font-family: var(--font-sans);
  font-size: 0.68rem;
  font-weight: 600;
  letter-spacing: 0.15em;
  text-transform: uppercase;
  color: var(--accent-blue);
  margin-bottom: 0.3rem;
}
.abstract-text {
  font-family: var(--font-serif);
  font-size: 0.95rem;
  color: var(--text-secondary);
  line-height: 1.55;
}

/* ── Section heading ── */
.section-heading {
  font-family: var(--font-sans);
  font-size: 0.68rem;
  font-weight: 600;
  letter-spacing: 0.18em;
  text-transform: uppercase;
  color: var(--text-muted);
  border-bottom: 1px solid var(--rule-color);
  padding-bottom: 0.3rem;
  margin: 1.4rem 0 0.8rem;
}

/* ── Query input styling ── */
.stTextArea textarea {
  font-family: var(--font-serif) !important;
  font-size: 1rem !important;
  color: var(--text-primary) !important;
  background: var(--column-bg) !important;
  border: 1px solid var(--card-border) !important;
  border-radius: 4px !important;
  padding: 0.8rem !important;
  line-height: 1.5 !important;
}
.stTextArea textarea:focus {
  border-color: var(--accent-blue) !important;
  box-shadow: 0 0 0 2px rgba(26,58,92,0.1) !important;
}

/* ── Buttons ── */
.stButton > button {
  font-family: var(--font-sans) !important;
  font-size: 0.82rem !important;
  font-weight: 600 !important;
  letter-spacing: 0.08em !important;
  text-transform: uppercase !important;
  background-color: var(--accent-blue) !important;
  color: white !important;
  border: none !important;
  border-radius: 3px !important;
  padding: 0.55rem 1.6rem !important;
}
.stButton > button:hover {
  background-color: #0e2340 !important;
}

/* ── Result card (citation-style) ── */
.result-card {
  background: var(--column-bg);
  border: 1px solid var(--card-border);
  border-radius: 4px;
  padding: 1.2rem 1.4rem;
  margin-bottom: 1rem;
  position: relative;
}
.result-card:hover {
  border-color: var(--accent-blue);
  box-shadow: 0 2px 8px rgba(26,58,92,0.08);
}
.result-rank {
  font-family: var(--font-sans);
  font-size: 0.65rem;
  font-weight: 600;
  letter-spacing: 0.15em;
  text-transform: uppercase;
  color: var(--text-muted);
  margin-bottom: 0.2rem;
}
.result-standard-id {
  font-family: var(--font-mono);
  font-size: 0.82rem;
  font-weight: 600;
  color: var(--accent-blue);
  background: var(--tag-bg);
  border: 1px solid var(--tag-border);
  border-radius: 3px;
  padding: 0.1rem 0.45rem;
  display: inline-block;
  margin-bottom: 0.3rem;
}
.result-title {
  font-family: var(--font-serif);
  font-size: 1.15rem;
  font-weight: 600;
  color: var(--text-primary);
  margin: 0.2rem 0 0.1rem;
  line-height: 1.3;
}
.result-category {
  font-family: var(--font-sans);
  font-size: 0.72rem;
  color: var(--text-muted);
  letter-spacing: 0.06em;
  text-transform: uppercase;
  margin-bottom: 0.6rem;
}

/* ── Confidence meter ── */
.conf-row {
  display: flex;
  align-items: center;
  gap: 0.7rem;
  margin: 0.5rem 0;
}
.conf-label {
  font-family: var(--font-sans);
  font-size: 0.7rem;
  font-weight: 600;
  letter-spacing: 0.1em;
  text-transform: uppercase;
  color: var(--text-muted);
  min-width: 80px;
}
.conf-track {
  flex: 1;
  height: 6px;
  background: var(--score-track);
  border-radius: 3px;
  overflow: hidden;
}
.conf-fill {
  height: 100%;
  border-radius: 3px;
  transition: width 0.4s ease;
}
.conf-value {
  font-family: var(--font-mono);
  font-size: 0.78rem;
  font-weight: 600;
  min-width: 38px;
  text-align: right;
}

/* ── Score component breakdown ── */
.score-breakdown {
  display: flex;
  gap: 0.8rem;
  margin: 0.4rem 0 0.6rem;
  flex-wrap: wrap;
}
.score-pill {
  font-family: var(--font-mono);
  font-size: 0.7rem;
  padding: 0.15rem 0.5rem;
  border-radius: 2px;
  border: 1px solid;
}
.score-dense  { color: #1a3a5c; background: #e8f0f8; border-color: #b8d0e8; }
.score-bm25   { color: #5c3a1a; background: #f8f0e8; border-color: #e8d0b8; }
.score-graph  { color: #1a5c2a; background: #e8f8ec; border-color: #b8e0c4; }

/* ── Rationale block ── */
.rationale-block {
  font-family: var(--font-serif);
  font-size: 0.95rem;
  color: var(--text-secondary);
  line-height: 1.65;
  margin: 0.5rem 0;
  padding: 0.7rem 1rem;
  background: #f8f7f4;
  border-left: 2px solid var(--rule-color);
  border-radius: 0 3px 3px 0;
}

/* ── Entity tags ── */
.entity-row {
  display: flex;
  flex-wrap: wrap;
  gap: 0.35rem;
  margin: 0.5rem 0;
  align-items: center;
}
.entity-label {
  font-family: var(--font-sans);
  font-size: 0.65rem;
  font-weight: 600;
  letter-spacing: 0.12em;
  text-transform: uppercase;
  color: var(--text-muted);
  margin-right: 0.2rem;
}
.entity-tag {
  font-family: var(--font-sans);
  font-size: 0.72rem;
  padding: 0.15rem 0.55rem;
  border-radius: 2px;
  border: 1px solid var(--tag-border);
  background: var(--tag-bg);
  color: var(--accent-blue);
}
.entity-matched {
  border-color: #90c090;
  background: #eef8ee;
  color: var(--accent-green);
  font-weight: 600;
}

/* ── Source chunk expander ── */
.chunk-box {
  font-family: var(--font-mono);
  font-size: 0.72rem;
  color: var(--text-muted);
  background: #f4f2ed;
  border: 1px solid var(--card-border);
  border-radius: 3px;
  padding: 0.7rem 0.9rem;
  line-height: 1.5;
  white-space: pre-wrap;
  word-break: break-word;
}

/* ── Latency badge ── */
.latency-badge {
  font-family: var(--font-mono);
  font-size: 0.7rem;
  color: var(--text-muted);
  background: #f0ede6;
  border: 1px solid var(--card-border);
  border-radius: 2px;
  padding: 0.15rem 0.55rem;
  display: inline-block;
}

/* ── Pipeline diagram boxes ── */
.pipeline-step {
  font-family: var(--font-sans);
  font-size: 0.7rem;
  font-weight: 600;
  letter-spacing: 0.08em;
  text-transform: uppercase;
  text-align: center;
  padding: 0.4rem 0.7rem;
  border-radius: 3px;
  border: 1px solid;
  display: inline-block;
  margin: 0.2rem;
}
.step-blue  { color: #1a3a5c; background: #e8f0f8; border-color: #b8d0e8; }
.step-green { color: #1a5c2a; background: #e8f8ec; border-color: #b8e0c4; }
.step-amber { color: #8b5a1a; background: #f8f0e0; border-color: #e8d0a0; }

/* ── Expander override ── */
.streamlit-expanderHeader {
  font-family: var(--font-sans) !important;
  font-size: 0.75rem !important;
  font-weight: 600 !important;
  letter-spacing: 0.08em !important;
  text-transform: uppercase !important;
  color: var(--text-muted) !important;
}

/* ── Selectbox / slider override ── */
[data-testid="stSlider"] label,
[data-testid="stSelectbox"] label {
  font-family: var(--font-sans) !important;
  font-size: 0.75rem !important;
  font-weight: 600 !important;
  letter-spacing: 0.1em !important;
  text-transform: uppercase !important;
  color: var(--text-muted) !important;
}

.stAlert {
  font-family: var(--font-sans) !important;
}

/* ── Divider ── */
hr { border-color: var(--rule-color); }
</style>
""", unsafe_allow_html=True)


# ── Sample queries ────────────────────────────────────────────────────────────
SAMPLE_QUERIES = [
    "TMT steel bars for RCC construction",
    "Ready-mix concrete for structural use in high-rise building",
    "Ordinary Portland Cement 43 grade for structural concrete",
    "Coarse and fine aggregate for M25 concrete mix design",
    "Portland Pozzolana Cement with fly ash for mass concrete",
    "Superplasticizer admixture for pumped concrete",
    "Fe500 deformed bars for bridge reinforcement",
    "Portland Slag Cement for marine construction",
]

# ── Confidence colour helper ──────────────────────────────────────────────────
def conf_color(score: float) -> str:
    if score >= 0.65:  return "#2d7a2d"   # green
    if score >= 0.40:  return "#c47a15"   # amber
    return "#b83232"                       # red


# ── Confidence bar HTML ───────────────────────────────────────────────────────
def conf_bar(label: str, value: float, color: str) -> str:
    pct = round(value * 100, 1)
    return f"""
<div class="conf-row">
  <span class="conf-label">{label}</span>
  <div class="conf-track">
    <div class="conf-fill" style="width:{pct}%;background:{color};"></div>
  </div>
  <span class="conf-value" style="color:{color};">{pct:.1f}%</span>
</div>"""


# ── Entity tag HTML ───────────────────────────────────────────────────────────
def entity_tags(
    items: list, matched: list = None, label: str = ""
) -> str:
    matched_set = set(m.lower() for m in (matched or []))
    html = f'<div class="entity-row"><span class="entity-label">{label}</span>'
    for item in items[:8]:
        cls = "entity-tag entity-matched" if item.lower() in matched_set else "entity-tag"
        html += f'<span class="{cls}">{item}</span>'
    html += "</div>"
    return html


# ── Lazy pipeline loader ──────────────────────────────────────────────────────
@st.cache_resource(show_spinner=False)
def load_pipeline():
    """Load pipeline once and cache across sessions."""
    from src.pipeline import BISPipeline
    return BISPipeline()


# ── Sidebar ───────────────────────────────────────────────────────────────────
with st.sidebar:
    st.markdown("""
    <div style="font-family:var(--font-sans);font-size:0.65rem;letter-spacing:0.15em;
                text-transform:uppercase;color:#7a7a74;margin-bottom:0.4rem;">
    Navigation
    </div>
    """, unsafe_allow_html=True)

    top_k = st.slider("Results returned", min_value=1, max_value=5, value=3,
                      help="Number of BIS standards to recommend")

    st.markdown("---")

    st.markdown("""
    <div style="font-family:var(--font-sans);font-size:0.65rem;letter-spacing:0.15em;
                text-transform:uppercase;color:#7a7a74;margin-bottom:0.5rem;">
    Quick Queries
    </div>
    """, unsafe_allow_html=True)

    preset_query = st.selectbox("Load example", ["— select —"] + SAMPLE_QUERIES,
                                label_visibility="collapsed")

    st.markdown("---")

    st.markdown("""
    <div style="font-family:var(--font-sans);font-size:0.65rem;letter-spacing:0.15em;
                text-transform:uppercase;color:#7a7a74;margin-bottom:0.5rem;">
    Scoring Weights
    </div>
    """, unsafe_allow_html=True)

    st.markdown("""
    <div style="font-family:var(--font-mono);font-size:0.72rem;color:#4a4a44;
                line-height:1.8;">
    Dense (FAISS) &nbsp;&nbsp;&nbsp; <b>0.50</b><br>
    BM25 Keyword &nbsp;&nbsp;&nbsp; <b>0.25</b><br>
    Graph Match &nbsp;&nbsp;&nbsp;&nbsp; <b>0.25</b>
    </div>
    """, unsafe_allow_html=True)

    st.markdown("---")

    st.markdown("""
    <div style="font-family:var(--font-sans);font-size:0.65rem;letter-spacing:0.15em;
                text-transform:uppercase;color:#7a7a74;margin-bottom:0.4rem;">
    Graph Edges
    </div>
    <div style="font-family:var(--font-sans);font-size:0.72rem;color:#4a4a44;line-height:1.8;">
    Standard → <span style="color:#1a3a5c">COVERS</span> Material<br>
    Standard → <span style="color:#1a5c2a">APPLIES_TO</span> Application<br>
    Standard → <span style="color:#8b5a1a">MENTIONS</span> Property<br>
    Standard → <span style="color:#5c1a5c">BELONGS_TO</span> Category
    </div>
    """, unsafe_allow_html=True)

    st.markdown("---")

    st.markdown("""
    <div style="font-family:var(--font-sans);font-size:0.65rem;letter-spacing:0.15em;
                text-transform:uppercase;color:#7a7a74;margin-bottom:0.4rem;">
    Technical Basis
    </div>
    <div style="font-family:var(--font-serif);font-size:0.82rem;color:#4a4a44;
                font-style:italic;line-height:1.55;">
    Graph retrieval inspired by candidate extraction &amp; entity neighbourhood
    aggregation in <i>HETGNN-FR: Detecting Coordinated Fraud Rings in Dynamic
    Financial Networks</i>.
    </div>
    """, unsafe_allow_html=True)


# ── Journal header ────────────────────────────────────────────────────────────
st.markdown("""
<div class="journal-header">
  <div class="journal-name">BIS × Sigma Squad AI Hackathon · MSE Compliance Track</div>
  <div class="paper-title">Accelerating BIS Standard Discovery for MSEs</div>
  <div class="paper-subtitle">A Graph-Enhanced Retrieval-Augmented Generation Framework</div>
  <div class="paper-meta">
    Graph-Enhanced RAG &nbsp;·&nbsp; Hybrid Dense–Sparse Retrieval &nbsp;·&nbsp;
    Knowledge Graph Ranking &nbsp;·&nbsp; LLM Rationale Generation
  </div>
</div>
""", unsafe_allow_html=True)

# ── Abstract ──────────────────────────────────────────────────────────────────
st.markdown("""
<div class="abstract-box">
  <div class="abstract-label">Abstract</div>
  <div class="abstract-text">
    Micro and Small Enterprises (MSEs) face significant friction identifying applicable
    Bureau of Indian Standards (BIS) for their building materials. This system presents
    a Graph-Enhanced RAG pipeline that converts a free-text product description into
    the top-ranked applicable BIS standards, complete with confidence scores and
    grounded rationale. The architecture combines dense semantic retrieval (BGE embeddings,
    FAISS), BM25 keyword search, and a lightweight knowledge graph whose entity
    neighbourhood matching is directly inspired by the heterogeneous temporal graph
    reasoning of <em>HETGNN-FR</em>.
  </div>
</div>
""", unsafe_allow_html=True)


# ── Query section ──────────────────────────────────────────────────────────────
st.markdown('<div class="section-heading">§ 1 &nbsp; Product Description Query</div>',
            unsafe_allow_html=True)

default_query = ""
if preset_query and preset_query != "— select —":
    default_query = preset_query

query_text = st.text_area(
    "Enter product description",
    value=st.session_state.get("query_val", default_query),
    height=90,
    placeholder='e.g. "TMT steel bars Fe500 grade for RCC construction in multi-storey building"',
    label_visibility="collapsed",
)

col_run, col_clear = st.columns([1, 5])
with col_run:
    run_btn = st.button("▶  Discover Standards")
with col_clear:
    if st.button("Clear"):
        st.session_state["query_val"] = ""
        st.rerun()

if run_btn and query_text.strip():
    st.session_state["query_val"] = query_text

    # ── Load pipeline (cached) ────────────────────────────────────────────────
    with st.spinner("Loading retrieval pipeline …"):
        try:
            pipeline = load_pipeline()
        except Exception as e:
            st.error(f"Pipeline load error: {e}\n\nMake sure you ran `python run_setup.py` first.")
            st.stop()

    # ── Run query ─────────────────────────────────────────────────────────────
    with st.spinner("Running graph-enhanced retrieval …"):
        output = pipeline.run(query_text.strip(), top_k=top_k)

    results    = output["results"]
    latency_ms = output["latency_ms"]

    if not results:
        st.warning("No standards found. Try a different product description.")
        st.stop()

    # ── Results header ────────────────────────────────────────────────────────
    st.markdown('<div class="section-heading">§ 2 &nbsp; Recommended BIS Standards</div>',
                unsafe_allow_html=True)

    col_l, col_r = st.columns([6, 1])
    with col_l:
        st.markdown(f"""
        <span style="font-family:var(--font-serif);font-size:0.92rem;
                     color:var(--text-secondary);">
        Query: <em>"{query_text}"</em>
        </span>
        """, unsafe_allow_html=True)
    with col_r:
        st.markdown(
            f'<span class="latency-badge">⏱ {latency_ms} ms</span>',
            unsafe_allow_html=True
        )

    # ── Result cards ──────────────────────────────────────────────────────────
    for rank, std in enumerate(results, start=1):
        conf       = std["confidence"]
        color      = conf_color(conf)
        matched    = std.get("matched_entities", [])
        rationale  = std.get("rationale", "—")
        materials  = std.get("material", [])
        apps       = std.get("application", [])
        keywords   = std.get("keywords", [])

        with st.container():
            st.markdown(f"""
            <div class="result-card">
              <div class="result-rank">Result #{rank} of {len(results)}</div>
              <div>
                <span class="result-standard-id">{std['standard_id']}</span>
              </div>
              <div class="result-title">{std['title']}</div>
              <div class="result-category">{std['category']}</div>

              {conf_bar("Overall", conf, color)}
              {conf_bar("Dense", std['dense_sim'], "#1a3a5c")}
              {conf_bar("BM25", std['bm25_score'], "#8b5a1a")}
              {conf_bar("Graph", std['graph_score'], "#1a5c2a")}

              <div class="score-breakdown">
                <span class="score-pill score-dense">Dense × 0.50</span>
                <span class="score-pill score-bm25">BM25 × 0.25</span>
                <span class="score-pill score-graph">Graph × 0.25</span>
              </div>

              {entity_tags(matched, matched, "Matched") if matched else ""}
              {entity_tags(materials, matched, "Materials")}
              {entity_tags(apps, matched, "Applications")}

              <div style="margin-top:0.6rem;">
                <div style="font-family:var(--font-sans);font-size:0.65rem;
                             font-weight:600;letter-spacing:0.1em;text-transform:uppercase;
                             color:var(--text-muted);margin-bottom:0.25rem;">
                  Rationale
                </div>
                <div class="rationale-block">{rationale}</div>
              </div>
            </div>
            """, unsafe_allow_html=True)

            with st.expander("▸ Retrieved Source Chunk"):
                st.markdown(f"""
                <div class="chunk-box">{std.get('chunk_text','—')[:600]}</div>
                <div style="margin-top:0.4rem;font-family:var(--font-mono);
                             font-size:0.65rem;color:var(--text-muted);">
                  Source: {std.get('source_file','—')} &nbsp;|&nbsp; Pages: {std.get('page','—')}
                </div>
                """, unsafe_allow_html=True)

    # ── Score summary table ───────────────────────────────────────────────────
    st.markdown('<div class="section-heading">§ 3 &nbsp; Ranking Score Summary</div>',
                unsafe_allow_html=True)

    import pandas as pd
    df = pd.DataFrame([
        {
            "Standard": r["standard_id"],
            "Title":    r["title"][:45] + "…" if len(r["title"]) > 45 else r["title"],
            "Final":    r["confidence"],
            "Dense":    r["dense_sim"],
            "BM25":     r["bm25_score"],
            "Graph":    r["graph_score"],
            "Matched":  ", ".join(r.get("matched_entities", [])[:3]) or "—",
        }
        for r in results
    ])
    st.dataframe(
        df.style.format({"Final": "{:.4f}", "Dense": "{:.4f}",
                         "BM25": "{:.4f}", "Graph": "{:.4f}"}),
        use_container_width=True,
        hide_index=True,
    )

elif run_btn:
    st.warning("Please enter a product description before searching.")

else:
    # ── Landing state ─────────────────────────────────────────────────────────
    st.markdown('<div class="section-heading">§ 2 &nbsp; Pipeline Architecture</div>',
                unsafe_allow_html=True)

    st.markdown("""
    <div style="font-family:var(--font-serif);font-size:0.95rem;
                color:var(--text-secondary);line-height:1.7;margin-bottom:1rem;">
    The system implements a three-stage candidate ranking pipeline, directly
    analogous to the architecture of <em>HETGNN-FR</em> adapted from financial
    fraud ring detection to standards discovery:
    </div>

    <div style="text-align:center;margin:0.8rem 0;">
      <span class="pipeline-step step-blue">① Dense Retrieval<br><small>BGE + FAISS</small></span>
      <span style="font-size:1.2rem;color:#c8c0b0;padding:0 0.3rem;">→</span>
      <span class="pipeline-step step-amber">② Sparse Retrieval<br><small>BM25 Okapi</small></span>
      <span style="font-size:1.2rem;color:#c8c0b0;padding:0 0.3rem;">→</span>
      <span class="pipeline-step step-green">③ Graph Boost<br><small>NetworkX KG</small></span>
      <span style="font-size:1.2rem;color:#c8c0b0;padding:0 0.3rem;">→</span>
      <span class="pipeline-step step-blue">④ LLM Rationale<br><small>Claude Haiku</small></span>
    </div>

    <div style="font-family:var(--font-mono);font-size:0.78rem;color:#4a4a44;
                background:#f4f2ed;border:1px solid #d8d0c0;border-radius:3px;
                padding:0.8rem 1.1rem;margin:0.8rem 0;line-height:1.8;">
    final_score = <b>0.50</b> × dense_similarity<br>
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; + <b>0.25</b> × bm25_score<br>
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; + <b>0.25</b> × graph_match_score
    </div>
    """, unsafe_allow_html=True)

    st.markdown('<div class="section-heading">§ 3 &nbsp; Supported Standards (Seed Set)</div>',
                unsafe_allow_html=True)

    seed_data = [
        ("IS 456",  "Plain and Reinforced Concrete",           "Structural Concrete"),
        ("IS 383",  "Coarse and Fine Aggregates",              "Aggregates"),
        ("IS 269",  "OPC 33 Grade",                            "Cement"),
        ("IS 8112", "OPC 43 Grade",                            "Cement"),
        ("IS 12269","OPC 53 Grade",                            "Cement"),
        ("IS 1489", "Portland Pozzolana Cement",               "Cement"),
        ("IS 455",  "Portland Slag Cement",                    "Cement"),
        ("IS 1786", "High Strength Deformed Steel Bars (TMT)", "Steel"),
        ("IS 432",  "Mild Steel Bars",                         "Steel"),
        ("IS 4926", "Ready Mixed Concrete",                    "RMC"),
        ("IS 10262","Concrete Mix Proportioning",              "Mix Design"),
        ("IS 9103", "Concrete Admixtures",                     "Admixtures"),
    ]
    import pandas as pd
    df_seed = pd.DataFrame(seed_data, columns=["Standard ID", "Title", "Category"])
    st.dataframe(df_seed, use_container_width=True, hide_index=True)
